// 交易所数据
export const EXCHANGES = {
    mexc: {
        id: 'mexc',
        name: 'MEXC交易所',
        apiUrl: 'https://www.mexc.com/open/api/v2/market/ticker'
    },
    xt: {
        id: 'xt',
        name: 'XT交易所',
        apiUrl: 'https://api.xt.com/v4/public/ticker'
    },
    binance: {
        id: 'binance',
        name: '币安交易所',
        apiUrl: 'https://api.binance.com/api/v3/ticker/price'
    },
    okex: {
        id: 'okex',
        name: 'OKEX交易所',
        apiUrl: 'https://www.okex.com/api/spot/v3/instruments/ticker'
    },
    hotcoin: {
        id: 'hotcoin',
        name: 'HOTCOIN交易所',
        apiUrl: 'https://api.hotcoinfin.com/v1/market/ticker'
    }
};

// 排序选项
export const SORT_OPTIONS = [
    { value: 'symbol-asc', label: '按币名升序' },
    { value: 'symbol-desc', label: '按币名降序' },
    { value: 'price-asc', label: '按价格升序' },
    { value: 'price-desc', label: '按价格降序' },
    { value: 'market_cap_rank-asc', label: '按T升序' },
    { value: 'market_cap_rank-desc', label: '按T降序' }
];

// 面板配置
export const PANEL_CONFIG = {
    1: {
        titleSelector: '[data-panel="1"] .exchange-title',
        countSelector: '[data-panel="1"] .exchange-count',
        rowsSelector: '[data-panel="1"] .exchange-rows'
    },
    2: {
        titleSelector: '[data-panel="2"] .exchange-title',
        countSelector: '[data-panel="2"] .exchange-count',
        rowsSelector: '[data-panel="2"] .exchange-rows'
    },
    3: {
        searchId: 'same-pairs-search',
        rowsId: 'same-pairs-row'
    },
    4: {
        searchId: 'high-diff-stats-search',
        rowsId: 'high-diff-stats'
    }
};

// 默认排序状态
export const DEFAULT_SORT_ORDERS = {
    1: { symbol: 'asc', price: 'asc', market_cap_rank: 'asc' },
    2: { symbol: 'asc', price: 'asc', market_cap_rank: 'asc' },
    3: { symbol: 'asc', price1: 'asc', price2: 'asc', diff: 'asc', market_cap_rank: 'asc' },
    4: { symbol: 'asc', maxDiff: 'asc', greaterThan_0_1: 'asc', greaterThan_0_03: 'asc', greaterThan_0_02: 'asc', market_cap_rank: 'asc' }
};