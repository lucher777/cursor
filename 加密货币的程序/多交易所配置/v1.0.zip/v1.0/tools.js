// 获取本地存储项
function getLocalStorageItem(key) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : null;
    } catch (error) {
        console.error(`Error retrieving ${key} from local storage:`, error);
        return null;
    }
}


// 工具函数
const formatUtils = {
    removeTrailingZeros: num => parseFloat(num).toString(),
    formatVolume(volume) {
        if (volume >= 1e8) return `$${(volume / 1e8).toFixed(3)}亿`;
        if (volume >= 1e4) return `$${(volume / 1e4).toFixed(3)}万`;
        return `$${volume.toFixed(3)}`;
    },
    getCoinData(symbol) {
        const storedCoins = getLocalStorageItem('top3000Coins');
        return storedCoins ? storedCoins.data.find(c => c.symbol.toUpperCase() === symbol.toUpperCase()) : null;
    },
    // 计算背景色的亮度
    calculateBrightness(r, g, b) {
        return (r * 299 + g * 587 + b * 104) / 1000;
    },
    localStoredCoins(){
        const storedCoins = getLocalStorageItem('top3000Coins');
        if (!storedCoins) return;
        return storedCoins;
    }
};

// 导出 formatUtils 对象，以便在其他文件中使用
export { formatUtils };