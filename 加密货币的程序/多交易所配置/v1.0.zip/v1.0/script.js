import { loadData, findSamePairs, EXCHANGES } from './api.js';

import { formatUtils } from './tools.js';

import { DEFAULT_SORT_ORDERS } from './staticData.js';


// 可以删除原有的静态数据定义
// 常量配置
const DIFF_THRESHOLD = 0.01;
const PANEL_CONFIG = {
    1: {
        titleSelector: '[data-panel="1"] .exchange-title',
        countSelector: '[data-panel="1"] .exchange-count',
        rowsSelector: '[data-panel="1"] .exchange-rows'
    },
    2: {
        titleSelector: '[data-panel="2"] .exchange-title',
        countSelector: '[data-panel="2"] .exchange-count',
        rowsSelector: '[data-panel="2"] .exchange-rows'
    },
    3: {
        searchId: 'same-pairs-search',
        rowsId: 'same-pairs-row'
    },
    4: {
        searchId: 'high-diff-stats-search',
        rowsId: 'high-diff-stats'
    }
};

// 初始化面板结构，移除 sortSelect 相关逻辑
const PANEL_MAP = Object.fromEntries(
    Object.entries(PANEL_CONFIG).map(([id, config]) => {
        const base = id <= 2 ? {
            title: document.querySelector(config.titleSelector),
            count: document.querySelector(config.countSelector),
            rows: document.querySelector(config.rowsSelector),
            data: []
        } : {
            searchInput: document.getElementById(config.searchId),
            rows: document.getElementById(config.rowsId),
            data: []
        };
        return [id, base];
    })
);

// 应用状态，移除 sortConfig
const appState = {
    totalCount: parseInt(sessionStorage.getItem('totalCount')) || 0,
    firstTime: sessionStorage.getItem('firstTime') || null,
    lastTime: sessionStorage.getItem('lastTime') || null,
    sessionStats: JSON.parse(sessionStorage.getItem('highDiffStats')) || {}
};

// 移除全局排序状态
// 移除原有的sortOrders定义
// const sortOrders = {
//     1: { symbol: 'asc', price: 'asc', market_cap_rank: 'asc' },
//     2: { symbol: 'asc', price: 'asc', market_cap_rank: 'asc' },
//     3: { symbol: 'asc', price1: 'asc', price2: 'asc', diff: 'asc', market_cap_rank: 'asc' },
//     4: { symbol: 'asc', maxDiff: 'asc', greaterThan_0_1: 'asc', greaterThan_0_03: 'asc', greaterThan_0_02: 'asc', market_cap_rank: 'asc' }
// };

// 直接使用导入的DEFAULT_SORT_ORDERS
const sortOrders = DEFAULT_SORT_ORDERS;



// 核心功能
const template = {
    symbolCell(symbol, icon) {
        return `
            <div class="flex items-center space-x-2">
                <div style="${icon ? `background-image:url('${icon}')` : 'background-color:#e0e0e0'};
                    width:20px;height:20px;border-radius:50%;background-size:contain;">
                </div>
                <a href="#" target="_blank">${symbol}</a>
            </div>
        `;
    },
    priceCell(value, compareValue, link) {
        const isHigher = value > compareValue;
        return `
            <a href="${link}" target="_blank" class="${isHigher ? 'price-high' : 'price-low'}">
                $${value} ${isHigher ? '↑' : '↓'}
            </a>
        `;
    },
    
    loadingState() {
        return `
            <tr>
                <td colspan="4" class="text-center py-8">
                    <div class="flex flex-col items-center justify-center space-y-2">
                        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                        <span class="text-gray-600">数据加载中...</span>
                    </div>
                </td>
            </tr>
        `;
    },
    
    emptyState() {
        return `
            <tr>
                <td colspan="4" class="text-center py-8">
                    <div class="flex flex-col items-center justify-center space-y-2">
                        <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <span class="text-gray-500">请选择交易所查看数据</span>
                    </div>
                </td>
            </tr>
        `;
    }
};

// 修改updatePanel函数中的加载状态显示
function updatePanel(exchange, panelId, data) {
    const panel = PANEL_MAP[panelId];
    panel.data = data;

    if (panelId <= 2) {
        panel.count.textContent = `交易对数量: ${data.length}`;
    }

    // 添加加载中和空状态判断
    if (!data || data.length === 0) {
        panel.rows.innerHTML = template.emptyState();
        return;
    }

    panel.rows.innerHTML = data.map(item => {
        const price = formatUtils.removeTrailingZeros(item.price);
        const rank = item.market_cap_rank || '-';
        return `
            <tr>
                <td>${template.symbolCell(item.symbol, item.icon)}</td>
                <td><a href="${item.priceLink}" target="_blank">$${price}</a></td>
                <td style="width:10%">${rank}</td>
            </tr>
        `;
    }).join('');
}

function comparePairs() {
    const exchange1 = document.getElementById('exchange-select-1').value;
    const exchange2 = document.getElementById('exchange-select-2').value;

    if (!exchange1 || !exchange2) {
        alert('请先选择两个交易所！');
        return;
    }

    const pairs = findSamePairs(PANEL_MAP[1].data, PANEL_MAP[2].data);
    // 移除排序调用
    // sortAndDisplayPairs(pairs);
    displayComparison(pairs);
    updateStats(pairs);

}

// 移除排序相关函数
// function sortAndDisplayPairs(pairs) {
//     PANEL_MAP[3].data = pairs;
//     sortTable(3, 'diff', 'desc');
//     displayComparison(pairs);
// }

// 移除切换排序方向函数
function toggleSort(panelId, column) {
    const currentOrder = sortOrders[panelId][column];
    const newOrder = currentOrder === 'asc' ? 'desc' : 'asc';
    sortOrders[panelId][column] = newOrder;
    sortTable(panelId, column, newOrder);
    updateSortIcon(panelId, column, newOrder);
}

// 移除更新排序图标函数
// function updateSortIcon(panelId, column, order) {
//     const iconId = `sort-icon-${panelId}-${column}`;
//     const icon = document.getElementById(iconId);
//     icon.classList.remove('fa-arrow-up', 'fa-arrow-down', 'fa-sort');
//     if (order === 'asc') {
//         icon.classList.add('fa-arrow-up');
//     } else {
//         icon.classList.add('fa-arrow-down');
//     }
// }

// 移除排序表格函数
export function sortTable(panelId, column, direction) {
    const panel = document.querySelector(`[data-panel="${panelId}"]`);
    const tbody = panel.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    rows.sort((a, b) => {
        const aValue = a.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
        const bValue = b.querySelector(`td:nth-child(${getColumnIndex(column)})`).textContent;
        
        if (column === 'symbol') {
            return direction === 'asc' ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue);
        }
        
        const aNum = parseFloat(aValue.replace(/[^\d.-]/g, ''));
        const bNum = parseFloat(bValue.replace(/[^\d.-]/g, ''));
        return direction === 'asc' ? aNum - bNum : bNum - aNum;
    });

    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
}

function getColumnIndex(column) {
    // 根据列名返回对应的列索引
    const columns = {
        'symbol': 1,
        'price': 2,
        'market_cap_rank': 3,
        'price1': 2,
        'price2': 3,
        'diff': 4,
        'maxDiff': 2,
        'greaterThan_0_1': 3,
        'greaterThan_0_03': 4,
        'greaterThan_0_02': 5
    };
    return columns[column] || 1;
}

// 显示对比结果 面板3
function displayComparison(pairs) {
    // 先排序再显示
    const sortedPairs = [...pairs].sort((a, b) => parseFloat(b.diff) - parseFloat(a.diff));
    
    PANEL_MAP[3].rows.innerHTML = sortedPairs.map(pair => {
        const cleanPrice1 = formatUtils.removeTrailingZeros(pair.price1);
        const cleanPrice2 = formatUtils.removeTrailingZeros(pair.price2);

        const price1Class = pair.price1 > pair.price2 ? 'text-red-500' : 'text-green-500';
        const price2Class = pair.price1 > pair.price2 ? 'text-green-500' : 'text-red-500';
        const arrow1 = pair.price1 > pair.price2 ? '↑' : '↓';
        const arrow2 = pair.price1 > pair.price2 ? '↓' : '↑';

        const diffPercent = Math.min(parseFloat(pair.diff), 100);
        const backgroundColor = `rgba(255, 0, 0, ${diffPercent / 100})`;

        return `
            <tr>
                <td>${template.symbolCell(pair.symbol, pair.icon)}</td>
                <td><a href="${pair.price1Link}" target="_blank" class="${price1Class}">$${cleanPrice1} ${arrow1}</a></td>
                <td><a href="${pair.price2Link}" target="_blank" class="${price2Class}">$${cleanPrice2} ${arrow2}</a></td>
                <td data-diff="${pair.diff}" class="diff-cell" style="background-color: ${backgroundColor}; color: black;">${pair.diff}%</td>
                <td>${pair.rank || '-'}</td>
            </tr>
        `;
    }).join('');
    
    document.getElementById('same-pairs-count').textContent = `交易对数量: ${sortedPairs.length}`;
}

// 统计功能
function updateStats(pairs) {
    const newStats = pairs.reduce((acc, { symbol, diff }) => {
        const numDiff = parseFloat(diff);
        if (numDiff <= DIFF_THRESHOLD) return acc;

        const existing = acc[symbol] || { count: 0, maxDiff: -Infinity, diffs: [] };
        return {
            ...acc,
            [symbol]: {
                count: existing.count + 1,
                maxDiff: Math.max(existing.maxDiff, numDiff),
                diffs: [...existing.diffs, numDiff]
            }
        };
    }, { ...appState.sessionStats });
    appState.sessionStats = newStats;
    sessionStorage.setItem('highDiffStats', JSON.stringify(newStats));
    displayStats(Object.entries(newStats).map(([s, v]) => ({ symbol: s, ...v })));
}

// 面板4
function displayStats(stats) {
    PANEL_MAP[4].rows.innerHTML = stats.map(stat => {
        const coinData = formatUtils.getCoinData(stat.symbol);
        const diffPercent = Math.min(parseFloat(stat.maxDiff), 100);
        const backgroundColor = `rgba(255, 0, 0, ${diffPercent / 100})`;

        return `
            <tr>
                <td>${template.symbolCell(stat.symbol, coinData?.image)}</td>
                <td style="background-color: ${backgroundColor}; color: black;">${stat.maxDiff.toFixed(2)}%</td>
                <td>${stat.diffs.filter(d => d >= 0.1).length}</td>
                <td>${stat.diffs.filter(d => d >= 0.03).length}</td>
                <td>${stat.diffs.filter(d => d >= 0.02).length}</td>
                <td>${coinData?.market_cap_rank || '-'}</td>
            </tr>
        `;
    }).join('');
}

// 初始化逻辑，移除排序下拉框事件监听
function init() {
    // 初始化交易所选择框
    ['exchange-select-1', 'exchange-select-2'].forEach(id => {
        const select = document.getElementById(id);
        while(select.options.length > 1) {
            select.remove(1);
        }
        
        Object.values(EXCHANGES).forEach(ex => {
            const option = new Option(ex.name, ex.id);
            select.add(option);
        });

        // 为每个选择框添加change事件监听
        select.addEventListener('change', async (e) => {
            const panelId = id.split('-')[2]; // 从exchange-select-1获取1
            const panel = PANEL_MAP[panelId];
            panel.rows.innerHTML = e.target.value
                ? '<tr><td colspan="4">⏳ 加载中...</td></tr>'
                : '<tr><td colspan="4" class="text-center text-gray-500">请选择交易所查看数据</td></tr>';

            if (e.target.value) {
                try {
                    const data = await loadData(e.target.value);
                    console.log('加载的数据:', data);
                    updatePanel(EXCHANGES[e.target.value], panelId, data);
                    updateSessionState(e.target.value, data);

                    // 5秒后自动执行数据匹配功能
                    setTimeout(() => {
                        matchData();
                        // 如果两个面板都已选择，则自动比较交易对
                        if (document.getElementById('exchange-select-1').value && 
                            document.getElementById('exchange-select-2').value) {
                            comparePairs();
                        }
                    }, 5000);
                } catch (error) {
                    console.error('加载数据失败:', error);
                    panel.rows.innerHTML = '<tr><td colspan="4" class="text-center text-red-500">加载失败，请重试</td></tr>';
                }
            }
        });
    });

    [3, 4].forEach(panelId => {
        PANEL_MAP[panelId].searchInput.addEventListener('input', e => {
            const query = e.target.value.toLowerCase();
            const dataSource = panelId === 3
               ? PANEL_MAP[3].data
                : Object.entries(appState.sessionStats).map(([s, d]) => ({ symbol: s, ...d }));

            const filtered = dataSource.filter(item =>
                item.symbol.toLowerCase().includes(query)
            );

            panelId === 3 ? displayComparison(filtered) : displayStats(filtered);
        });
    });

    document.getElementById('matchBtn').addEventListener('click', matchData);
}

// 辅助功能
function updateSessionState(exchangeId, data) {
    const now = new Date().toLocaleTimeString();
    appState.totalCount += data.length;
    appState.firstTime = appState.firstTime || now;
    appState.lastTime = now;

    sessionStorage.setItem('totalCount', appState.totalCount);
    sessionStorage.setItem('firstTime', appState.firstTime);
    sessionStorage.setItem('lastTime', appState.lastTime);

    document.getElementById('total-count').textContent = appState.totalCount;
    document.getElementById('first-time').textContent = appState.firstTime;
    document.getElementById('last-time').textContent = appState.lastTime;
}

function matchData() {
    const storedCoins = formatUtils.localStoredCoins();
    if (!storedCoins) return;
    const coinData = storedCoins.data;
    
    // 保存面板3的原始数据
    const originalPairs = [...PANEL_MAP[3].data];
    
    [1, 2].forEach(panelId => {
        PANEL_MAP[panelId].data.forEach(item => {
            const match = coinData.find(c => c.symbol.toUpperCase() === item.symbol.toUpperCase());
            item.market_cap_rank = match?.market_cap_rank || '-';
            item.icon = match?.image;
        });
        updatePanel(null, panelId, PANEL_MAP[panelId].data);
    });

    // 更新面板3的数据但保留原始对比结果
    PANEL_MAP[3].data = originalPairs.map(pair => {
        const match = coinData.find(c => c.symbol.toUpperCase() === pair.symbol.toUpperCase());
        return {
            ...pair,
            icon: match?.image,
            rank: match?.market_cap_rank || '-'
        };
    });
        displayComparison(PANEL_MAP[3].data);
}

function searchCoin() {
    const input = document.getElementById('search-input');
    const result = document.getElementById('search-result');
    const content = document.getElementById('search-result-content');
    const term = input.value.trim().toUpperCase();

    if (!term) {
        result.style.display = 'none';
        return;
    }

    const coinData = formatUtils.getCoinData(term);
    if (coinData) {
        content.innerHTML = `
            <div class="bg-white p-4 rounded shadow-md">
                <div class="flex items-center space-x-4">
                    <div style="background-image:url('${coinData.image}');background-size:contain;width:64px;height:64px;border-radius:50%"></div>
                    <div>
                        <p class="text-xl font-bold">${coinData.symbol}</p>
                        <p class="text-gray-600">${coinData.name}</p>
                    </div>
                </div>
                <div class="mt-4">
                    <p><strong>币价:</strong> $${formatUtils.removeTrailingZeros(coinData.current_price)}</p>
                    <p><strong>排名:</strong> ${coinData.market_cap_rank || '-'}</p>
                    <p><strong>24小时成交量:</strong> ${formatUtils.formatVolume(coinData.total_volume)}</p>
                    <p><strong>24小时市值变化:</strong> ${coinData.market_cap_change_percentage_24h?.toFixed(2) || '0'}%</p>
                </div>
            </div>
        `;
    } else {
        content.innerHTML = '<p class="bg-white p-4 rounded shadow-md text-red-500">未找到该交易对信息</p>';
    }
    result.style.display = 'block';
}

function closeSearchResult() {
    document.getElementById('search-result').style.display = 'none';
}



export { 
    init, 
    comparePairs, 
    toggleSort,
    matchData, 
    searchCoin, 
    closeSearchResult 
};
    