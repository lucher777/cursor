// CoinGecko API 配置
const COINGECKO_API = {
    baseUrl: 'https://api.coingecko.com/api/v3',
    getMarkets: (params) => `${COINGECKO_API.baseUrl}/coins/markets?${new URLSearchParams(params)}`
};

// 存储前 30 次请求（最多 7500 个）市值的币的数据
let top3000CoinsData = [];
// 当前请求的次数
let currentRequestCount = 1;
// 定时器 ID
let intervalId;
// 请求间隔时间
let settime = 20000;
// 数据有效期（1 小时）
const DATA_EXPIRATION_TIME = 12 * 60 * 60 * 1000;
// 最大请求次数
const MAX_REQUESTS = 30;

// 获取指定页面的币种数据
async function fetchCoinData() {
    try {
        const response = await fetch(COINGECKO_API.getMarkets({
            vs_currency: 'usd',
            order: 'market_cap_desc',
            per_page: 250,
            page: currentRequestCount,
            sparkline: 'false'
        }));
        if (!response.ok) {
            throw new Error(`CoinGecko API 请求失败，状态码: ${response.status}`);
        }
        const pageData = await response.json();
        updateTop3000CoinsData(pageData);
        saveTop3000CoinsToLocalStorage();
        return pageData;
    } catch (error) {
        console.error('获取币种数据时出错:', error);
        return [];
    }
}

// 更新 top3000CoinsData 中的数据
function updateTop3000CoinsData(pageData) {
    pageData.forEach(newCoin => {
        const existingIndex = top3000CoinsData.findIndex(coin => coin.id === newCoin.id && coin.name === newCoin.name);
        if (existingIndex !== -1) {
            top3000CoinsData[existingIndex] = newCoin;
        } else {
            top3000CoinsData.push(newCoin);
        }
    });
}

// 将 top3000CoinsData 保存到本地存储
function saveTop3000CoinsToLocalStorage() {
    const expirationDate = new Date();
    expirationDate.setTime(expirationDate.getTime() + DATA_EXPIRATION_TIME);
    const dataToSave = {
        data: top3000CoinsData.slice(0, MAX_REQUESTS * 250),
        expiration: expirationDate.getTime()
    };
    try {
        localStorage.setItem('top3000Coins', JSON.stringify(dataToSave));
    } catch (error) {
        if (error instanceof DOMException && error.code === 22) {
            console.error('本地存储容量不足，尝试清理部分数据');
            // 可以添加清理旧数据的逻辑
        }
    }
}

// 检查本地存储是否有有效数据
function checkLocalStorage() {
    const storageStatusElement = document.getElementById('storage-status');
    const storedData = localStorage.getItem('top3000Coins');
    if (storedData) {
        const { expiration } = JSON.parse(storedData);
        const now = new Date().getTime();
        if (now < expiration) {
            storageStatusElement.textContent = '本地存储有有效数据，无需重新获取';
            retrieveTop3000CoinsFromLocalStorage();
            return true;
        }
    }
    storageStatusElement.textContent = '本地存储无有效数据，开始获取数据';
    return false;
}

// 从本地存储中获取 top3000Coins 数据
function retrieveTop3000CoinsFromLocalStorage() {
    const storedData = localStorage.getItem('top3000Coins');
    if (storedData) {
        const { data } = JSON.parse(storedData);
        top3000CoinsData = data;
    }
    const statusElement = document.getElementById('fetch-status');
    statusElement.textContent = '从本地存储加载数据完成，正在处理...';
    processAndSaveData();
}

// 启动定时请求
async function startFetching() {
    if (checkLocalStorage()) {
        return;
    }
    const statusElement = document.getElementById('fetch-status');
    statusElement.textContent = '正在获取数据...';
    intervalId = setInterval(async () => {
        if (currentRequestCount > MAX_REQUESTS) {
            clearInterval(intervalId);
            statusElement.textContent = '已达到最大请求次数，数据获取完成，正在处理...';
            await processAndSaveData();
            return;
        }
        const pageData = await fetchCoinData();
        statusElement.textContent = `已完成第 ${currentRequestCount} 次请求，当前累计数据数量: ${top3000CoinsData.length}`;
        currentRequestCount++;
    }, settime);
}

// 处理并保存数据到本地存储
async function processAndSaveData() {
    const saveStatusElement = document.getElementById('save-status');
    saveStatusElement.textContent = '正在保存数据...';
    const processedData = top3000CoinsData.slice(0, MAX_REQUESTS * 250).map(coin => ({
        id: coin.id,
        symbol: coin.symbol,
        name: coin.name,
        image: coin.image,
        total_volume: coin.total_volume,
        market_cap_rank: coin.market_cap_rank,
        market_cap: coin.market_cap,
        market_cap_change_percentage_24h: coin.market_cap_change_percentage_24h
    }));

    const expirationDate = new Date();
    expirationDate.setTime(expirationDate.getTime() + DATA_EXPIRATION_TIME);
    const dataToSave = {
        data: processedData,
        expiration: expirationDate.getTime()
    };

    localStorage.setItem('top3000Coins', JSON.stringify(dataToSave));
    saveStatusElement.textContent = '数据保存完成';
    updateLocalStorageStatus();
}

// 更新本地存储状态显示
function updateLocalStorageStatus() {
    const storageStatusElement = document.getElementById('storage-status');
    const storedData = localStorage.getItem('top3000Coins');
    if (storedData) {
        const { expiration } = JSON.parse(storedData);
        const now = new Date().getTime();
        if (now < expiration) {
            storageStatusElement.textContent = '本地存储有有效数据';
        } else {
            storageStatusElement.textContent = '本地存储数据已过期';
            localStorage.removeItem('top3000Coins');
        }
    } else {
        storageStatusElement.textContent = '本地存储无数据';
    }
}

// 删除本地存储
function deleteLocalStorage() {
    localStorage.removeItem('top3000Coins');
    updateLocalStorageStatus();
    const saveStatusElement = document.getElementById('save-status');
    saveStatusElement.textContent = '本地存储已删除';
}

// 更新本地存储
function updateLocalStorage() {
    top3000CoinsData = [];
    currentRequestCount = 1;
    startFetching();
}

// 导出相关函数
export { startFetching, deleteLocalStorage, updateLocalStorage, updateLocalStorageStatus };    