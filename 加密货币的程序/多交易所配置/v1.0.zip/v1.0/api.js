// 初始化筛选配置（默认空对象）
let FILTER_CONFIG = {
    mexc: [],
    xt: [],
    binance : ["AERGO", "ERN", "SNT", "CLV", "CTXC", "BAL", "BADGER", "NULS", "ELF", "BETH", "ANT", "MULTI", "SRM", "AST", "AUTO", "BOND", "MIR", "TCT", "UNFI", "VITE", "BTS", "QI", "REN", "ANC", "IRIS", "LOOM", "VGX", "REEF", "KP3R", "OOKI", "BEAM", "YFII", "LINA", "BURGER", "WNXM", "OMG", "MFT", "XMR", "TORN", "POLS", "TRIBE", "EPX", "BETA", "CREAM", "FIRO", "HNT", "AMB", "PROS", "HARD", "COMBO", "VIDT", "WAVES", "BLZ","UFT"],
    okex: [],
    hotcoin: []
};

// 异步加载筛选配置文件，失败时不影响主流程
(async () => {
    try {
        const module = await import('https://api.panpans.cn/filterConfig.js');
        const serverConfig = module.FILTER_CONFIG || {};
        // 遍历 FILTER_CONFIG 的每个属性
        for (const key in FILTER_CONFIG) {
            if (Object.prototype.hasOwnProperty.call(FILTER_CONFIG, key)) {
                if (Array.isArray(FILTER_CONFIG[key]) && Array.isArray(serverConfig[key])) {
                    // 拼接本地和服务器上的数组
                    FILTER_CONFIG[key] = FILTER_CONFIG[key].concat(serverConfig[key]);
                }
            }
        }
    } catch (error) {
        console.log('筛选配置文件加载失败，使用默认空配置');
    }
})();

    
import { formatUtils } from './tools.js';

// 交易所配置（保持原接口调用，新增USDT结尾过滤和数值为0过滤）
const EXCHANGES = {
    mexc: {
        name: 'MEXC',
        id:'mexc',
        api: 'https://api.panpans.cn/mexc-api-proxy',
        parser: (data) => data
           .filter(item => item.symbol.toUpperCase().endsWith('USDT') && parseFloat(item.price) !== 0) // 过滤非USDT结尾且价格不为0
        .filter(item => {
            const symbolWithoutUSDT = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
            return !FILTER_CONFIG.mexc.includes(symbolWithoutUSDT);
        }) // 应用筛选配置
           .map(item => {
                const symbol = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
                const originalSymbol = symbol.toUpperCase() + '_USDT';
                const link = `https://www.mexc.com/zh-MY/exchange/${originalSymbol}`;
                const time = item.time ? new Date(item.time).toLocaleTimeString() : new Date().toLocaleTimeString();
                const timeColor = item.time ? '' : 'text-gray-500';
                return {
                    symbol,
                    price: parseFloat(item.price),
                    time,
                    timeColor,
                    symbolLink: link,
                    priceLink: link
                };
            }),
        ending: 'USDT'
    },
    xt: {
        name: 'XT',
        id:'xt',
        api: 'https://api.panpans.cn/xt-api-proxy',
        parser: (data) => data.result
           .filter(item => item.s.toUpperCase().endsWith('_USDT') && parseFloat(item.p) !== 0) // 过滤非USDT结尾且价格不为0
        .filter(item => {
            const symbolWithoutUSDT = item.s.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
            return !FILTER_CONFIG.xt.includes(symbolWithoutUSDT);
        }) // 应用筛选配置
           .map(item => {
                const symbol = item.s.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
                const originalSymbol = symbol.toLowerCase() + '_usdt';
                const link = `https://www.xt.com/zh-CN/trade/${originalSymbol}`;
                const time = item.t ? new Date(item.t).toLocaleTimeString() : new Date().toLocaleTimeString();
                const timeColor = item.t ? '' : 'text-gray-500';
                return {
                    symbol,
                    price: parseFloat(item.p),
                    time,
                    timeColor,
                    symbolLink: link,
                    priceLink: link
                };
            }),
        ending: '_usdt'
    },
    binance: {
        name: '币安',
        id:'binance',
        api: 'https://api.panpans.cn/binance-api-proxy',
        parser: (data) => data
           .filter(item => item.symbol.toUpperCase().endsWith('USDT') && parseFloat(item.price) !== 0) // 过滤非USDT结尾且价格不为0
        .filter(item => {
            const symbolWithoutUSDT = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
            return !FILTER_CONFIG.binance.includes(symbolWithoutUSDT);
        }) // 应用筛选配置
           .map(item => {
                const symbol = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
                const originalSymbol = symbol.toUpperCase() + '_USDT';
                const link = `https://www.binance.com/zh-CN/trade/${originalSymbol}`;
                const time = new Date().toLocaleTimeString();
                const timeColor = 'text-gray-500';
                return {
                    symbol,
                    price: parseFloat(item.price),
                    time,
                    timeColor,
                    symbolLink: link,
                    priceLink: link
                };
            }),
        ending: 'USDT'
    },
    okex: {
        name: 'OKEX',
        id:'okex',
        api: 'https://api.panpans.cn/okex-api-proxy',
        parser: (data) => data.data
           .filter(item => item.instId.toUpperCase().endsWith('USDT') && parseFloat(item.last) !== 0) // 过滤非USDT结尾且价格不为0
        .filter(item => {
            const symbolWithoutUSDT = item.instId.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
            return !FILTER_CONFIG.okex.includes(symbolWithoutUSDT);
        }) // 应用筛选配置
           .map(item => {
                const symbol = item.instId.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
                const originalSymbol = symbol.toLowerCase() + '-usdt';
                const link = `https://www.okx.com/zh-hans/trade-spot/${originalSymbol}`;
                const time = item.ts ? new Date(Number(item.ts)).toLocaleTimeString() : new Date().toLocaleTimeString();
                const timeColor = item.ts ? '' : 'text-gray-500';
                return {
                    symbol,
                    price: parseFloat(item.last),
                    time,
                    timeColor,
                    symbolLink: link,
                    priceLink: link
                };
            }),
        ending: 'USDT'
    },
    hotcoin: {
        name: 'HOTCOIN',
        id:'hotcoin',
        api: 'https://api.panpans.cn/hotcoin-api-proxy',
        parser: (data) => data.ticker
           .filter(item => item.symbol.toUpperCase().endsWith('USDT') && parseFloat(item.last) !== 0) // 过滤非USDT结尾且价格不为0
        .filter(item => {
            const symbolWithoutUSDT = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
            return !FILTER_CONFIG.hotcoin.includes(symbolWithoutUSDT);
        }) // 应用筛选配置
           .map(item => {
                const symbol = item.symbol.toUpperCase().replace(/_|-/g, '').replace('USDT', '');
                const originalSymbol = symbol.toLowerCase() + '_usdt';
                const link = `https://www.hotcoin.com/zh_CN/trade/exchange/?tradeCode=${originalSymbol}`;
                const time = item.time ? new Date(item.time).toLocaleTimeString() : new Date().toLocaleTimeString();
                const timeColor = item.time ? '' : 'text-gray-500';
                return {
                    symbol,
                    price: parseFloat(item.last),
                    time,
                    timeColor,
                    symbolLink: link,
                    priceLink: link
                };
            }),
        ending: 'USDT'
    }
};

// 加载数据主函数
async function loadData(exchangeId) {
    const exchange = EXCHANGES[exchangeId];
    if (!exchange) return [];
    try {
        const response = await fetch(exchange.api);
        if (!response.ok) {
            throw new Error(`请求失败: ${response.status}`);
        }

        const rawData = await response.json();
        console.log('获取到数据:', rawData); // 调试日志
        return exchange.parser(rawData);
    } catch (error) {
        console.error(`加载 ${exchange.name} 数据失败:`, error);
        return [];
    }
}

// 查找相同交易对（对交易对名称进行标准化处理）
function findSamePairs(data1, data2) {
    const symbolMap = new Map();

    data1.forEach(item => {
        symbolMap.set(item.symbol, { price: item.price, priceLink: item.priceLink });
    });

    return data2.flatMap(item => {
        if (symbolMap.has(item.symbol)) {
            const price1 = parseFloat(symbolMap.get(item.symbol).price);
            const price2 = parseFloat(item.price);
            const diff = ((Math.max(price1, price2) - Math.min(price1, price2)) / Math.min(price1, price2)) * 100;
            const coinData = formatUtils.getCoinData(item.symbol);
            return {
                symbol: item.symbol,
                price1,
                price2,
                diff: diff.toFixed(2),
                price1Link: symbolMap.get(item.symbol).priceLink,
                price2Link: item.priceLink,
                rank:coinData?.market_cap_rank || '-',
                icon:coinData?.image || '-'
            };
        }
        return null;
    }).filter(Boolean);
}

export { loadData, findSamePairs, EXCHANGES };